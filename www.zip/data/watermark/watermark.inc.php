<?php	if(!defined('IN_PHPMYWIND')) exit('Request Error!');

$cfg_markswitch = 'N';
$cfg_marktype = '0';
$cfg_markminwidth = '100';
$cfg_markminheight = '100';
$cfg_markpicurl = 'data/watermark/watermarket.png';
$cfg_marktext = 'PHPMyWind';
$cfg_markcolor = '#0000FF';
$cfg_marksize = '48';
$cfg_markwhere = '9';

?>