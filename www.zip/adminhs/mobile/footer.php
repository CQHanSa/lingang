<?php	if(!defined('IN_MOBILE')) exit('Request Error!'); ?>
<div class="footer"><?php echo date('Y',time());?> © HANSA</div>