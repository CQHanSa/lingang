<div class="order_menu t_left">
        	<ul>
            	<li>
                    <dl>
                    	<dt><a href="javascript:;">商品管理</a></dt>
                    	<dd><a href="?action=goodstype">商品分类</a></dd>
                    	<dd><a href="?action=goods">商品管理</a></dd>
                    	<dd><a href="?action=goodscomment">商品评价</a></dd>
                    </dl>
                </li>
            	<li>
                	<dl>
                    	<dt><a href="javascript:;">交易管理</a></dt>
                    	<dd><a href="?action=goodsorder">订单管理</a></dd>
                    </dl>
                </li>
            	<li>
                	<dl>
                    	<dt><a href="javascript:;">网店设置</a></dt>
                    	<dd><a href="?action=editinfo">店铺资料</a></dd>
                        <dd><a href="?action=shops_announcement">店铺公告</a></dd>
                        <dd><a href="?action=shops_note">购物须知</a></dd>
                    	<dd><a href="?action=message">商城信息</a></dd>
                        <dd><a href="?action=shopad">店铺广告</a></dd>
                    </dl>
				</li>
            </ul>
        </div>
        