<div class="order_menu t_left">
        	<ul>
            	<li>
                	<dl>
                    	<dt><a href="javascript:;">个人信息</a></dt>
                    	<dd><a href="?action=editinfo">个人资料</a></dd>
                    	<dd><a href="?action=editpswd">安全中心</a></dd>
                    	<dd><a href="?action=shipping_address">收货地址</a></dd>
                    </dl>
                </li>
            	<li>
                	<dl>
                    	<dt><a href="javascript:;">订单中心</a></dt>
                    	<dd><a href="#">我的订单</a></dd>
                        <dd><a href="#">我的团购</a></dd>
                        <dd><a href="?action=integral">我的积分</a></dd>
                        <dd><a href="#">我的购物车</a></dd>
                    </dl></li>
            	<li>
                	<dl>
                    	<dt><a href="javascript:;">关注中心</a></dt>
                    	<dd><a href="?action=shopCollection">收藏的店铺</a></dd>
                    	<dd><a href="?action=goodsCollection">收藏的商品</a></dd>
                    </dl></li>
                 <li>
                	<dl>
                    	<dt><a href="javascript:;">资产中心</a></dt>
                    	<dd><a href="?action=coupon">优惠券管理</a></dd>
                    	<dd><a href="?action=balance">账户余额</a></dd>
                        <dd><a href="?action=editpaypswd">支付密码设置</a></dd>
                    </dl></li>
                 <li>
                	<dl>
                    	<dt><a href="javascript:;">客户服务</a></dt>
                    	<dd><a href="#">退换货处理</a></dd>
                    	<dd><a href="/feedback.php">意见建议</a></dd>
                        <dd><a href="#">我的咨询</a></dd>
                    </dl></li>   
            </ul>
        </div>
        