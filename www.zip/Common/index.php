﻿<?php
session_start();
//完全路径
$path = 'd:\wamp\www';
//$path = 'd:\rootwww\cqfeiniao\web';

//调用数据库类
include_once($path.'/include/config.inc.php');
include_once($path.'/Common/function.class.php');
include_once($path.'/Common/mysql.class.php');
include_once($path.'/Common/temp.class.php');
include_once($path.'/Common/member.class.php');

/*
//开启数据库
//
*/

$GLOBALS['db_host'];
$GLOBALS['db_user'];
$GLOBALS['db_pwd'];
$GLOBALS['db_name'];
$GLOBALS['db_tablepre'];
//$rest  = mysql_connect($GLOBALS['db_host'],$GLOBALS['db_user'],$GLOBALS['db_pwd']) ;
$rest = mysqli_connect($GLOBALS['db_host'],$GLOBALS['db_user'],$GLOBALS['db_pwd'],$GLOBALS['db_name']);
//print_r( $rest );
if(is_user('islogin') == true){ $user = is_user('par'); }else{ $user = '';}

$type = isset($_GET['type']) ? get('type') : '';
$city  = isset($_COOKIE['city']) ?  AuthCode($_COOKIE['city'],'DECODE') : '3000';
$oncid = isset($_GET['oncid']) ? intval(get('oncid')) : '';
$twcid = isset($_GET['twcid']) ? intval(get('twcid')) : '';
$thcid = isset($_GET['thcid']) ? intval(get('thcid')) : '';
$page = isset($_GET['page']) ? intval(get('page')) : 0;

//


/*
_______________#########_______________________
______________############_____________________
______________#############____________________
_____________##__###########___________________
____________###__######_#####__________________
____________###_#######___####_________________
___________###__##########_####________________
__________####__###########_####_______________
________#####___###########__#####_____________
_______######___###_########___#####___________
_______#####___###___########___######_________
______######___###__###########___######_______
_____######___####_##############__######______
____#######__#####################_#######_____
____#######__##############################____
___#######__######_#################_#######___
___#######__######_######_#########___######___
___#######____##__######___######_____######___
___#######________######____#####_____#####____
____######________#####_____#####_____####_____
_____#####________####______#####_____###______
______#####______;###________###______#________
________##_______####________####______________

*/

?>
